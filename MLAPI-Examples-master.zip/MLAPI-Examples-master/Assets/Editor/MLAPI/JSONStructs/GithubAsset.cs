﻿using System;

[Serializable]
public class GithubAsset
{
    public string browser_download_url;
    public string name;
}
